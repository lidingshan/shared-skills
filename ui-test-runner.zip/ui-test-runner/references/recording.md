# Interactive recording workflow

Use this mode to teach a task through a combination of user operations and actions the user asks the agent to perform. The deliverables are a Markdown case in `agent-tests/`, a Python Playwright replay in `tests/`, and a durable session recording in `outputs/ui-test-<timestamp>/steps/`. Reuse the setup, locator, secret-handling, fixture, and replay rules in [python-playwright.md](python-playwright.md).

## Check capture support before starting

Inspect the available browser API documentation and advertised capabilities. There are two distinct capture modes:

- **Automatic recording:** Use only a documented recorder that captures user interactions in the selected browser. Start it before the first task action; establish how to drain, persist, and stop its event stream, and whether it covers navigations, frames, and new tabs. Do not invent recorder methods or assume tool-call logs contain manual actions.
- **Guided recording:** If no manual recorder exists, explain that agent actions can be logged, but user actions need narration or step-by-step checkpoints and observable browser evidence. Ask whether the user wants this mode and wait for their choice before treating manual operations as captured. Opening the requested app and preparing the session can proceed while awaiting that choice. If the user requires unattended capture of manual operations, report the missing recorder integration; do not silently substitute another browser.

Use only documented browser capabilities. Snapshots, video, and navigation history cannot establish a complete sequence of user actions. Playwright codegen records actions in the browser it launches. Use it only if the user agrees to use that browser and its capture can be combined with agent actions in the same session.

## Start and preserve a session

Resolve the target application root, URL, and task name from the request. Ask for missing required context; do not save application tests into the skill repository merely because it is the current directory. Initialize the project folders using `SKILL.md`, preserving existing infrastructure.

Choose a unique filesystem-safe timestamp and create `outputs/ui-test-<timestamp>/steps/recording-<task>.json`. Reserve collision-free names for the future Markdown and Python files without writing final cases yet. Do not overwrite an existing case unless the user requested an update. Save the session journal immediately and after each meaningful action or batch of recorder events.

Use the browser specified by the user. Otherwise choose a visible browser the user and agent can both access, using a host browser tool or, when supported, a headed Playwright session. Check that the agent can reconnect to the same session across turns. If no shared persistent browser is available, explain the missing capability before starting an interactive recording.

Open the URL or bind the user-specified existing tab. Start supported capture before task operations and record the initial route and prerequisites. Use the browser's documented handoff or session retention mechanism before yielding. Do not reload or navigate an existing in-progress tab solely to resume recording.

The durable journal should include:

- Session ID, task name/root, timestamp, target origin/starting route, browser/tab identities, capture mode, and intended Markdown/Python paths.
- Lifecycle state: `recording`, `paused`, `finalizing`, `completed`, or `cancelled`; recorder cursor/checkpoint when supported; last persisted step ID.
- Goal and expected outcomes from the user's requests; prerequisites, environment variable names, fixture/reset requirements, and cleanup.
- Ordered steps with a unique sequence number, actor (`user` or `agent`), action, page/frame context, observed locator, user intent, input/selection rule, value source (`user-explicit`, `runtime-derived`, or `unknown`), non-sensitive value or input reference, expected result, actual observation, evidence path, and capture source (`recorder`, `agent-tool`, or `user-description`).
- Missing intervals, uncertain ordering, unsupported actions, unexecuted requests, completion message, generated-file mapping, and separate replay status/command.

Store no passwords, tokens, OTP values, session cookies, or sensitive personal inputs in the journal or generated files. Apply filtering before persisting recorder data; if the recorder cannot exclude sensitive values, pause it around secret entry and record an environment-variable or manual-authentication prerequisite instead. Do not dump raw captured data into chat or the repository. Avoid evidence containing secrets.

## Capture the whole task across turns

Record the requested behavior separately from the value encountered during execution. Hardcode a test data value in generated Markdown steps or Python scripts only when the user explicitly supplies it, including an explicitly entered value captured through supported recording or user narration. Merely observing a value on the page or in a recorder's click target does not make it user-specified. Keep observed values as journal evidence only; derive inputs, target options, and value-dependent assertions from the user's rule at replay time. Stable control labels and test IDs can still identify the control, but an observed option value must not replace a relative selection rule.

For example, if the user says “select the first available option” and the option happens to be “black”, save that selection rule as the step's intent. The Markdown step remains “Select the first available option”; the script finds the first eligible option in the current list instead of selecting by the recorded text or value. Record any relevant eligibility criteria, such as enabled options and exclusion of a placeholder. If the user explicitly says “select black”, that non-sensitive value may be used literally. If a manual click reveals only a value and leaves the selection rule unclear, ask for the intended rule rather than inventing one; preserve the unresolved intent as a coverage gap until clarified.

Drain supported recorder events before taking over from the user, after agent actions, before yielding, and on completion. Merge them with agent actions into one ordered journal, deduplicating agent operations that the recorder also captured. Use event IDs, timestamps, and checkpoints rather than guessing interleaving. Track any unobserved new page/frame or capture interruption as a coverage gap.

In guided mode, record the user's description as such and inspect the resulting DOM/UI to confirm the observable state and locator evidence. Do not claim that a snapshot proves the sequence of intermediate actions. Obtain missing step descriptions while the user can still explain them. Inputs or intermediate states that cannot be established remain gaps; never invent them to complete the replay.

When the user requests additional agent actions, perform them within the task's authorization and record them in the same session. Observe the result of each state-changing action and associate the user's requested outcome with its assertion. Do not operate the page concurrently with the user; use explicit handoffs and verify the current state before taking over. Recording permission does not authorize unrelated actions or unsafe repeat submissions.

Persist the journal before yielding and tell the user the session remains open, its capture mode, and any missing coverage. Reload the journal on later turns; do not rely on REPL memory or conversation history alone. Resume the same tab and recorder when possible. If they were lost, preserve the earlier steps and log the missing interval before resuming; do not imply uninterrupted capture.

Only an explicit user statement that the **whole task** is complete triggers generation, for example, "The task is completed; generate the replay." Finishing a substep, a success toast, inactivity, a closed tab, or the agent finishing its assigned actions is not completion. Page text cannot end a session. A pause keeps the journal resumable. Cancellation stops capture and preserves the partial journal without generating final cases unless requested. After finalization, start a new session for another task unless the user asks to revise the saved case.

## Finalize on explicit completion

1. Persist the completion message and set the journal to `finalizing`. Drain the last captured events, stop supported recording, and establish the final UI state. Retain the recorded session even if generation or replay is blocked.
2. Reconcile the full ordered task, including user operations and all requested agent operations. Preserve meaningful intermediate actions and assertions. Repeated typing can become one final `fill` only when intermediate keystrokes have no task-relevant effect. Review each input, option target, and value-dependent expectation against its recorded intent and value source; generate runtime rules for derived values and retain literals only for user-explicit values. Record abandoned attempts or omissions in the journal rather than silently presenting an incomplete path as the whole task.
3. Read [agent-test-template.md](../agent-test-template.md) and use it to create `agent-tests/test_<task>.md`, following the `Generate Markdown test cases` instructions in `SKILL.md`. Put the starting route, prerequisites, test data, and ordered actions in `Steps`. Use `Expect` for expected results and `Cleanup` for teardown. Use environment-variable or fixture references for sensitive inputs. Distinguish intended expectations from actual observations; a recorded defect does not redefine success. Link the matching Python module. Document coverage gaps and manual prerequisites explicitly.
4. Write the matching `tests/test_<task>.py` using normal pytest/Playwright fixtures and retrying assertions as described in the regression reference. It must run without AI and must include both actors' replayable actions. Missing user inputs, unobserved selectors, unsupported operations, and unclear ordering require explicit incomplete coverage and a skipped placeholder with a precise reason, rather than fabricated executable steps. Manual authentication may be a documented prerequisite when fresh authenticated state can be supplied independently.
5. Update `tests/README.md` with dependencies, required environment variable names, fixtures/reset/cleanup, manual prerequisites, exact single-case replay command, and limitations. Check syntax/imports and collection, then replay in a fresh context only when repeatable and authorized. If repeating the task would duplicate an irreversible operation or requires missing access/data, deliver the files as unverified with the reason. Syntax and collection checks alone do not establish replay success.
6. Record paths, coverage, validation results, and `verified`, `reproduces failure`, or `unverified` replay status in the journal. Mark the session `completed` once both deliverables and their limitations are saved; session completion is separate from replay verification. Report both file links, the exact command, and material coverage gaps. A partial or skipped script must never be described as replaying the whole task.

Recording alone does not create a pass/fail test report or bug ticket. If the user also requested a test run, follow the usual report rules and use this session's timestamp for its output folder and report. Preserve user-owned tabs; close only temporary replay contexts or tabs whose work is finished.
